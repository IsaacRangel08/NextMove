import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: const InicioScreen(),
    );
  }
}

class InicioScreen extends StatelessWidget {
  const InicioScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        Navigator.push(
          context,
          MaterialPageRoute(builder: (context) => const MapaScreen()),
        );
      },
      child: Scaffold(
        body: Center(
          child: Image.asset('../assets/1.png', fit: BoxFit.cover),
        ),
      ),
    );
  }
}

class MapaScreen extends StatefulWidget {
  const MapaScreen({super.key});

  @override
  _MapaScreenState createState() => _MapaScreenState();
}

class _MapaScreenState extends State<MapaScreen> {
  bool _isMenuVisible = false; // Controla la visibilidad del menú

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("HOME")),
      body: Stack(
        children: [
          // Imagen de fondo (mapa)
          Center(
            child: Image.asset('../assets/mapa.png', fit: BoxFit.cover),
          ),

          // Botón flotante para abrir menú
          Positioned(
            bottom: 30,
            right: 30,
            child: FloatingActionButton(
              onPressed: () {
                setState(() {
                  _isMenuVisible = !_isMenuVisible;
                });
              },
              backgroundColor: Colors.orange,
              child: const Icon(Icons.menu),
            ),
          ),

          // Menú con 3 botones pequeños (se muestra si _isMenuVisible es true)
          Visibility(
            visible: _isMenuVisible,
            child: Positioned(
              bottom: 100,
              right: 30,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  _menuButton("Opción 1"),
                  const SizedBox(height: 10),
                  _menuButton("Opción 2"),
                  const SizedBox(height: 10),
                  _menuButton("Opción 3"),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  // Widget para los botones del menú
  Widget _menuButton(String text) {
    return ElevatedButton(
      onPressed: () {
        // Acción del botón
      },
      style: ElevatedButton.styleFrom(
        backgroundColor: Colors.orange,
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
      ),
      child: Text(text, style: const TextStyle(color: Colors.white)),
    );
  }
}